clc;
close all;
kappa0_gpt = 0.00005;
beta = 100;
alpha = 0.99;
count = 1;
g =[];
omega = [];
for i = 0.00005:0.001:0.0210
    kappa_gpt = i;
    a = (kappa0_gpt/kappa_gpt);
    c = beta*(kappa_gpt - kappa0_gpt);
    temp = (1-alpha) + alpha*exp(-c);
    g(count,1) = temp;
    omega(count,1) = i;
    count = count + 1;
end

plot(omega,g,'-')
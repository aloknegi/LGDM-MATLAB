syms kappa0_gpt kappa_gpt
g = (kappa0_gpt/kappa_gpt)^eta;
f = diff(g,kappa_gpt)
% Anisotropic Based Localizing Gradient Damage Model with Nonlocal Strains as Adof%
% Shear Band Problem 18/09/2018 %
% Using relatively Large Length Scale Factor %
% Using Normalized Anisotropic Gradient Matrix %
% Without Using Alpha in Interaction Function %

function PSB_ShearBand_Localizing_Damage_Model_120by120_05_04_2019

%-----Localizing Gradient Damage Model based on Smooothed Stresses and Anisotropic Interaction Kernel------%
clc;
tic;
close all;
L = 60; % Length of the plate
D = 60; % Width of the plate
numx = 120; % Number of elements in X direction
numy = 120; % Number of elements in Y direction
stressState='PLANE_STRAIN';

%---------------------Material Parameters------------------%
nu = 0.2;  % Poisson's Ratio
E  = 20000; % Elastic Moduli
cc = 2; % Internal length i.e. Characteristic length
h = 1; % Thickness of Specimen
material_p =[nu, E, cc, h]; % Material Parameters

% Newton-Raphson Parameters

% nsteps = 205; % Number of Load Increments i.e. Load is applied in "nsteps" increments
nsteps = 340; % Number of Load Increments i.e. Load is applied in "nsteps" increments
tol = 0.00001; % Tolerance Value to check Newton-Raphson convergence
maxit = 100; % Maximum Number of iterations in a single Load increment step i.e. Newton-Raphson iterations

%-----------------Damage Parameters---------------------%
K = 1; % Sensitivity Parameter i.e. Governs the sensitivity in compression relative to that in tension. 
       % Usually it is set equal to the ratio of compressive strength and tensile strength.
alpha = 0.99; % Controls the residual interactions
beta = 120; % Controls the Slope of Softening Curve
hcoup = E*1e-9; % Coupling Modulus
eta = 4;
R = 0.04;
ft = 2; % Tensile Strength MPa
damage_p =[K alpha beta hcoup R eta]; % Damage Parameters

%-------------------------------Stiffness Matrix D--------------------------------------%
if ( strcmp(stressState,'PLANE_STRESS') )
    De = E/(1-nu^2)*[ 1   nu 0 ;
                      nu  1  0 ;
                       0   0  0.5*(1-nu) ];
elseif ( strcmp(stressState,'PLANE_STRAIN') )
    De = E/((1+nu)*(1-2*nu))*[1-nu  nu  0;
                              nu  1-nu 0;
                              0     0  (1-2*nu)/2];
end

%----------------------Element Type Selection and Mesh Generation-----------------------%

disp([num2str(toc),'   MESH GENERATION'])

pt1 = [0 0] ; pt2 = [L 0] ; pt3 = [L D] ; pt4 = [0 D] ;
elemType1 = 'Q4' ;
elemType2 = 'Q4' ;

[node1,element1] = meshRegion(pt1, pt2, pt3, pt4, numx, numy,elemType1);

[node2,element2] = meshRegion(pt1, pt2, pt3, pt4, numx, numy,elemType2);
numnode2 = size(node2,1);

if ( strcmp(elemType1,'Q8') )  
    % ------------------For Q8 Elements-------------------%
    % Four corner points
    nnx = 2*numx+1; % Number of nodes in X-direction
    nny = 2*numy+1; % Number of nodes in Y-direction
    numnode1 = size(node1,1);
    numelem = size(element1,1);
    urn =(nnx*nny)-(numx*numy);% upper right node number
    uln =urn-(nnx-1); % upper left node number
    lrn = nnx; % lower right node number
    lln = 1; % lower left node number
    
    % GET NODES ON ESSENTIAL BOUNDARY
    topEdge = [ uln:1:(urn-1); (uln+1):1:urn ]';
    botEdge = [ lln:1:(lrn-1); (lln+1):1:lrn ]';
    botNodes = unique(botEdge);
    topNodes = unique(topEdge);
    dispNodes = botNodes; % Displacement B.C nodes
    tracNodes = topNodes; % Traction B.C. nodes

elseif ( strcmp(elemType1,'Q4') ) 
    % ------------------For Q4 Elements-------------------%
    nnx = numx+1; % Number of nodes in X-direction
    nny = numy+1; % Number of nodes in Y-direction
    numnode1 = size(node1,1);
    numelem = size(element1,1);
    uln = nnx*(nny-1)+1;       % upper left node number
    urn = nnx*nny;             % upper right node number
    lrn = nnx;                 % lower right node number
    lln = 1;                   % lower left node number
    
    % GET NODES ON ESSENTIAL BOUNDARY
    topEdge  = [ uln:1:(urn-1); (uln+1):1:urn ]';
    botEdge  = [ lln:1:(lrn-1); (lln+1):1:lrn ]';
    botNodes   = unique(botEdge);
    topNodes   = unique(topEdge);
    dispNodes = botNodes; % Displacement B.C nodes
    tracNodes = topNodes; % Traction B.C. nodes
end


%----------------Fixed DOF's for Boundary Conditions-----------------------%
vdofs = dispNodes.*2;
udofs = 1;
upper_disp_node = tracNodes.*2;
lower_nodes = (dispNodes)*2;
%--------------------------------------------------------------------------%

%-----------------------Input Parameters-----------------------------% 
total_disp = numnode1*2; % Total unknown displacements % 2 dof per node
total_strain = numnode2*3; % Total unknown strains i.e. 3 additional dof per node
total_unknown = total_disp + total_strain; % Total Unknowns
u_tot =  zeros(total_disp,1); % Setting total unknown displacements to 0 initially
strain_tot = zeros(total_strain,1); % Setting total nonlocal equivalent strains to 0 initially
kappa = zeros(4*numelem,1); % History Parameter
D_st= zeros(4*numelem,1); % Damage Variable vector
NE_gp = zeros(4*numelem,1); % % Non-equivalent strain at Gauss Points
stress_gp = zeros(4*numelem,3);
forcevdisp = zeros(2,nsteps+1);
forcevdisp(1,1) = 0;
forcevdisp(2,1) = 0;

if numx == 20
 for i=1:1
    for j=1:2   
        Felement(i,j) = j + numx*(i-1);
    end
 end
elseif numx == 40
    for i=1:2
    for j=1:4   
        Felement(i,j) = j + numx*(i-1);
    end
    end
elseif numx == 60
    for i=1:3
    for j=1:6   
        Felement(i,j) = j + numx*(i-1);
    end
    end    
elseif  numx == 80   
for i=1:4
    for j=1:8   
        Felement(i,j) = j + numx*(i-1);
    end
end
elseif  numx == 100  
for i=1:5
    for j=1:10   
        Felement(i,j) = j + numx*(i-1);
    end
end
elseif  numx == 120
for i=1:6
    for j=1:12   
        Felement(i,j) = j + numx*(i-1);
    end
end
end

kappa0 = zeros(4*numelem,1); % Setting Initial History Variable
kappa0(:,1) = 0.0001; % Tensile Strength/Elastic Modulus 'ft/E'

for del=1:1:numelem
    if (ismember(del,Felement))
            a = (del-1)*4;
            kappa0(a+1,1) = 0.00005; 
            kappa0(a+2,1) = 0.00005;
            kappa0(a+3,1) = 0.00005;
            kappa0(a+4,1) = 0.00005;
    end
end

[Gpnt] = computing_gauss_location(numelem,elemType2,node2,element2); % Gauss Point Location Generation
DAMAGE_DATA = [];
NESTRAIN_DATA = [];
DISP_DATA = [];
NESTRAIN_DATA_NODES = [];
INTERNAL_FORCE = [];
INTERACTION_DATA = [];
SIGMA_XX = [];
SIGMA_YY = [];
SIGMA_XY = [];    
SIGMA_XX_smooth = [];
SIGMA_YY_smooth = [];
SIGMA_XY_smooth = [];
EQ_STRESS = [];
NEQ_STRESS = [];

%-----------------------Newton Raphson Loop-----------------------------% 
disp([num2str(toc),'  NEWTON RAPHSON LOOP BEGINS'])
for step = 1 : nsteps
    err3 = 1;
    nit = 0;
    Fint = zeros(total_unknown,1);
    fprintf(1,'\n Step %f Load %f\n',step);
    
%-----------For 355 Load Steps-----------%   
%     if step<=5 
%         ubar = -1.2e-3;
%     elseif step>5 
%         ubar = -2.7e-4;  
%     end
    if step<=5 
        ubar = -1.2e-3;
    elseif step>5 && step<=125 
        ubar = -5e-5;
    elseif step>125 && step<=250
        ubar = -1.44e-4;  
    elseif step>250
        ubar = -6e-4;
    end

    while ((err3>tol) && (nit<maxit))          % Newton Raphson loop
       
        nit = nit + 1;
        
        % Computing Stiffness Matrix and Internal Force Vector
        [K,FAI,FE,D_st,kappa,NE_gp,stress_gp,interaction,stress_gp_sm,eq_stress,neq_stress] = globalstiffness(u_tot,strain_tot,D_st,material_p,De,damage_p,numelem,total_disp,...
            total_strain,node1,element1,element2,node2,elemType1,elemType2,kappa0,kappa,NE_gp,stress_gp);                   
             
        Fint = [FAI;FE];
        R = Fint;
        
        % ------------------------------------------------
        %       Imposing Essential Boundary Conditions
        %-------------------------------------------------
%         disp([num2str(toc),'   IMPOSING ESSENTIAL BOUNDARY CONDITION'])        
        
        Kres = K;
        bcwt = 1; % Used to keep the conditioning of the K matrix
        Kres(udofs,:) = 0;   % zero out the rows and columns of the K matrix
        Kres(:,udofs) = 0;
        Kres(vdofs,:) = 0;
        Kres(:,vdofs) = 0;
        Kres(udofs,udofs) = bcwt*speye(length(udofs)); % put ones*bcwt on the diagonal
        Kres(vdofs,vdofs) = bcwt*speye(length(vdofs));        
        Kres(upper_disp_node,:) = 0;
        Kres(:,upper_disp_node) = 0;
        Kres(upper_disp_node,upper_disp_node) = bcwt*speye(length(upper_disp_node));
        
        if nit==1
            for kk = 1:total_unknown               
                for ll = 1:length(upper_disp_node)
                    zz = upper_disp_node(ll);
                    R(kk,:) = R(kk,:) - K(kk,zz)*ubar;
                end
            end
        end
        
        R(udofs) = 0 ; % Imposing B.C. on Residual
        R(vdofs) = 0 ; % Imposing B.C. on Residual
        
        if nit == 1
            R(upper_disp_node) = ubar;
        else
            R(upper_disp_node) = 0;
        end
        
        %------Solve for the correction---------%
        [du]= Kres\R;
        du1 = du(1:total_disp,1); % Displacement increment vector
        du2 = du((total_disp+1):total_unknown,1); % Non-Equivalent Strain increment vector
        u_tot = u_tot + du1; % Updating displacement vector
        strain_tot = strain_tot + du2; % Updating displacement vector                
        %------Checking convergence-----------------%

        wnorm1 = dot(u_tot,u_tot);
        wnorm2 = dot(strain_tot,strain_tot);
        err1 = dot(du1,du1);
        err2 = dot(du2,du2);
        err3 = dot(R,R);
        err1 = sqrt(err1/wnorm1); % rms error
        err2 = sqrt(err2/wnorm2);
        err3 = sqrt((err3)/(2*numnode1));
        fprintf(1,'Iteration number %d Correction-u %f Correction-ne %f Residual %f tolerance %f\n',nit,err1,err2,err3,tol);
    end
       
        DAMAGE_DATA(:,step) = D_st;
        NESTRAIN_DATA(:,step) = NE_gp;
        GPT_DATA = Gpnt;
        DISP_DATA(:,step) = u_tot;
        NESTRAIN_DATA_NODES(:,step) = strain_tot;
        INTERNAL_FORCE(:,step) = Fint;
        SIGMA_XX(:,step) = stress_gp(:,1);
        SIGMA_YY(:,step) = stress_gp(:,2);
        SIGMA_XY(:,step) = stress_gp(:,3);       
        SIGMA_XX_smooth(:,step) = stress_gp_sm(:,1);
        SIGMA_YY_smooth(:,step) = stress_gp_sm(:,2);
        SIGMA_XY_smooth(:,step) = stress_gp_sm(:,3);
        INTERACTION_DATA(:,step) = interaction;
        EQ_STRESS(:,step) = eq_stress;
        NEQ_STRESS(:,step) = neq_stress;        

        
        forcevdisp(1,step+1) = - mean(u_tot(upper_disp_node,:));
        forcevdisp(2,step+1) = - sum(Fint(lower_nodes,:));      
        save('SB_120by120_Beta_120_Date_11_02_19_Eta_4_R04_340steps.mat','DAMAGE_DATA','NESTRAIN_DATA','GPT_DATA','forcevdisp','DISP_DATA','NESTRAIN_DATA_NODES','INTERNAL_FORCE',...
            'INTERACTION_DATA','SIGMA_XX','SIGMA_YY','SIGMA_XY','SIGMA_XX_smooth','SIGMA_YY_smooth','SIGMA_XY_smooth','EQ_STRESS','NEQ_STRESS');
end

disp([num2str(toc),'  END OF NEWTON RAPHSON LOOP'])

end % End of MaiN PrograM COde functioN

function [Stif,fai,fe,D_st,kappa,NE_gp,stress_gp,interaction,stress_gp_sm,eq_stress,neq_stress] = globalstiffness(u_tot,strain_tot,D_st,material_p, ...
    De,damage_p,numelem,total_disp,total_strain,node1,element1,element2,node2,elemType1,elemType2,kappa0,kappa,NE_gp,stress_gp)

%-----------------Damage Parameters---------------------%
k = damage_p(1,1); 
alpha = damage_p(1,2);
beta = damage_p(1,3);
hcoup = damage_p(1,4);
R = damage_p(1,5);
eta = damage_p(1,6);
stress_gp_sm = zeros(4*numelem,3);
eq_stress = zeros(4*numelem,1);
neq_stress = zeros(4*numelem,1);

%-----------------Material Parameters-------------------%
nu = material_p(1,1); % Poisson Ratio
E = material_p(1,2); % Elastic Modulus
len_par = material_p(1,3); % Length Scale Parameter
th = material_p(1,4); % Thickness of the Specimen

del = [1; 1; 0];

H = [2 -1 0; 
    -1 2 0; 
     0 0 1.5];
 
tol = 1e-25; % Tolerance
total_unknown = total_disp + total_strain; % Total unknowns
gpnt = 0;
interaction = zeros(4*numelem,1);
fai = zeros(total_disp,1); % Internal Force vector
fe = zeros(total_strain,1); % Internal Force vector corresponding to non-equivalent strains
I = zeros(400*numelem,1);
J =  zeros(400*numelem,1);
S = zeros(400*numelem,1);
index = 0;

for iel = 1:numelem % Loop on elements  
    sctr = element2(iel,:); % Element connectivity 
    sctr1 = assembly(iel,element1);  
    sctr3 = assembly_nonlocal(sctr,total_disp);
    sctr2 = sctr3 - total_disp;
    
    % Choose Gauss quadrature rules for elements
    order = 2;
    [W,Q] = quadrature(order,'GAUSS',2);

    u_local = u_tot(sctr1,:);  % Displacement corresponding to each node of the element 
    strain_nonlocal = strain_tot(sctr2,:); % Non-local Equivalent strain corresponding to each node of the element
    s1 = size(u_local,1);
    s2 = size(strain_nonlocal,1);
    Stif1 = zeros(s1,s1);
    Stif2 = zeros(s1,s2);
    Stif3 = zeros(s2,s1);
    Stif4 = zeros(s2,s2);
    fai_gpt = zeros(s1,1);
    fe_gpt = zeros(s2,1);  
    
    for kk = 1 : size(W,1) 
        
        gpnt = gpnt + 1;
        e_tilde1 = kappa(gpnt,1); % Non-equivalent strain     
        pt = Q(kk,:);   % Quadrature point       
        [B1,J01] = xfemBmatrix1(pt,elemType1,iel,node1,element1); % B matrix and Jacobian for displacement vector         
        [N2,B2] = xfemBmatrix2(pt,elemType2,iel,node2,element2); % Shape Function
        
        strain_gpt_local = B1*u_local; % Computing Strain at Gaussian Point
        strain_gpt_nonlocal = N2*strain_nonlocal; % Computing Non-local Strain vector at Quadrature point
        del_strain_gpt_nl = B2*strain_nonlocal; % Computing gradient of Non-local Strain vector at Quadrature point
        kappa0_gpt = kappa0(gpnt,1);      

        % Computing Nonlocal Equivalent Strain from Nonlocal Strain Vector
        a1 = 1/(2*k);
        a2 = (k-1)/(1-2*nu);
        a3 = (2*k)/((1+nu)^2);
        a4 = 1/((1+nu)^2);       
        
        % Equivalent Strain Computation based on Local Strain
        exx_l = strain_gpt_local(1,1);
        eyy_l = strain_gpt_local(2,1);
        exy_l = strain_gpt_local(3,1); 
        eyx_l = strain_gpt_local(3,1);
        I1_l = exx_l + eyy_l;
        J2_l = (2*(exx_l^2) + 2*(eyy_l^2) - 2*(exx_l*eyy_l)) + 3*(exy_l^2+eyx_l^2);   
        AA_l = (a2*I1_l)^2 + (a3)*J2_l;        
                      
        exx = strain_gpt_nonlocal(1,1);
        eyy = strain_gpt_nonlocal(2,1);
        exy = strain_gpt_nonlocal(3,1); 
        eyx = strain_gpt_nonlocal(3,1);
        I1 = exx+eyy;
        J2 = (2*(exx^2) + 2*(eyy^2) - 2*(exx*eyy)) + 3*(exy^2+eyx^2);   
        AA = (a2*I1)^2 + (a3)*J2;
        
        if AA<=tol
            AA = tol;
        end
        
        if AA_l<=tol
            AA_l = tol;
        end        
        
        eps_l = a1*(a2*I1_l + sqrt(AA_l));        
        eps_nl = a1*(a2*I1 + sqrt(AA)); % Computing Nonlocal equivalent Strain from Strain Vector
        deps_de1 = a1*a2*(1 + a2*(AA^(-0.5))*I1)*del + a4*(AA^(-0.5))*H*strain_gpt_nonlocal;
        deps_de_nl = deps_de1'; % Derivation of Nonlocal Equivalent strain wrt Nonlocal strain vector
        
        %----------------------Stress Smoothening to Compute Interaction Kernel----------------------------%   
       
        if eps_l == 0
            eps_l = tol;
        end
        
        if eps_nl == 0
            eps_nl = tol;
        end
        
        f = eps_nl - e_tilde1; % Damage Loading Function
        
        if f>=0
            kappa_gpt = eps_nl;
        else
            kappa_gpt = e_tilde1;
        end
        
        % Exponential Cohesive Law i.e Damage Evolution Law         
        Omega = compute_damage(kappa_gpt,kappa0_gpt,alpha,beta);
        
        %------------------Constitutive Relations---------------------%
        sm_stress_gpt = De*(1-Omega)*strain_gpt_nonlocal; % Smooth Stress Vector
        
        if sm_stress_gpt== zeros(3,1)
            sm_stress_gpt(1,1) = tol;
            sm_stress_gpt(2,1) = tol;
            sm_stress_gpt(3,1) = tol;
        end
        
        sigxx = sm_stress_gpt(1,1);
        sigyy = sm_stress_gpt(2,1);
        sigxy = sm_stress_gpt(3,1);                         

        [sigma1, sigma2, theta] = Compute_Principal_Stress(sm_stress_gpt);
        ptheta = (pi/180)*theta;
        Rot = [cos(ptheta) -sin(ptheta); sin(ptheta) cos(ptheta)];
                

        [g,dgdomega] = interaction_function(eta,Omega,R); % Computing Interaction Function 

        
        c = (len_par^2);

        c11 = (sigxx^2 + sigxy^2)/max(sigma1^2,sigma2^2);
        c22 = (sigyy^2 + sigxy^2)/max(sigma1^2,sigma2^2);
        c12 = sigxy*(sigxx + sigyy)/max(sigma1^2,sigma2^2);
        Cbar1 = [c11 c12;
                  c12 c22]; 

        Cbar =  c*[Cbar1 zeros(2,4);
                   zeros(2,2) Cbar1  zeros(2,2);
                   zeros(2,4) Cbar1];
            
        stress_gpt = (1-Omega)*De*strain_gpt_local + hcoup*(strain_gpt_local-strain_gpt_nonlocal);  % Stress corresponding to strain           
        
        conjugate_stress_gpt = hcoup*(strain_gpt_nonlocal - strain_gpt_local); % Conjugate Stress to Non-equivalent strain
        
        xit_gpt = hcoup*g*Cbar*del_strain_gpt_nl; % Conjugate Stress to Gradient of Non-equivalent strain
               
               
        % Coefficient Omega
        if kappa_gpt < kappa0_gpt            
            DomegaDk = 0;  
        elseif e_tilde1 < eps_nl
            DomegaDk = (kappa0_gpt*(alpha*exp(beta*(kappa0_gpt - kappa_gpt)) - alpha + 1))/kappa_gpt^2 + (alpha*beta*kappa0_gpt*exp(beta*(kappa0_gpt - kappa_gpt)))/kappa_gpt;  
        else
            DomegaDk = 0;
        end    
        
        % Computing Stiffness Matrices
        
        Coff1 = B1'*((1-Omega)*De + hcoup)*B1;
               
        Stif1 = Stif1 + Coff1*W(kk)*det(J01)*th;          
        
        Coff3 = -B1'*(hcoup + De*strain_gpt_local*DomegaDk*deps_de_nl)*N2; 
        
        Stif2 = Stif2 + Coff3*W(kk)*det(J01)*th; % Stiffness matrix Kaa (8 x 4)
        
        Coff5 = -(N2'*hcoup*B1);
               
        Stif3 = Stif3 + Coff5*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 8);
        
        Coff6 = B2'*hcoup*g*Cbar*B2 + N2'*hcoup*N2 + B2'*hcoup*Cbar*del_strain_gpt_nl*dgdomega*DomegaDk*deps_de_nl*N2;

        Stif4 = Stif4 + (Coff6)*W(kk)*det(J01)*th; % Stiffness matrix Kea (4 x 4)  
        
        fai_gpt = fai_gpt - (B1'*stress_gpt)*W(kk)*det(J01)*th;
        
        fe_gpt = fe_gpt - (N2'*conjugate_stress_gpt + B2'*xit_gpt)*W(kk)*det(J01)*th;
        
        NE_gp(gpnt,1) = eps_nl;
        kappa(gpnt,1) = kappa_gpt;
        D_st(gpnt,1) = Omega;
        stress_gp(gpnt,:) = stress_gpt'; 
        interaction(gpnt,1) = g;       
        stress_gp(gpnt,:) = stress_gpt';
        stress_gp_sm(gpnt,:) = sm_stress_gpt';
        eq_stress(gpnt,:) = E*(1-Omega)*eps_l; 
        neq_stress(gpnt,:) = E*(1-Omega)*eps_nl;        
    end                  % end of looping on GPs   
    
    stif_temp = [Stif1 Stif2; Stif3 Stif4];
    a = [sctr1 sctr3];
    b = [sctr1 sctr3];
    
    for ti = 1:20
        for tj = 1:20
            index = index + 1;
            I(index) =  a(ti);
            J(index) =  b(tj);
            S(index) = stif_temp(ti,tj);
        end
    end
            
%     Stif(a,b) = Stif(a,b) + stif_temp;
    
    fai(sctr1',1) = fai(sctr1',1) + fai_gpt;
    fe(sctr2',1) = fe(sctr2',1) + fe_gpt;
end                      % end of looping on elements

Stif = sparse(I,J,S,total_unknown,total_unknown);

end

function sctrB = assembly_nonlocal(sctr,total_disp_local)

nn   = length(sctr); % Number of nodes
sctr_n = zeros(1,nn);
for i = 1:nn
a = sctr(i);    
b = a + total_disp_local;
sctr_n(i) = b + a*2;
end

sctr_nonlocal = zeros(1,12);

cnt = 0 ;

for k = 1 : nn
    cnt = cnt + 1 ;
    sctr_nonlocal(cnt) = sctr_n(k) - 2;

    cnt = cnt + 1 ;
    sctr_nonlocal(cnt) = sctr_n(k) - 1;
    
    cnt = cnt + 1 ;
    sctr_nonlocal(cnt) = sctr_n(k);
end
sctrB = sctr_nonlocal;
end


function X=square_node_array(pt1,pt2,pt3,pt4,numnod_u,numnod_v,uratio,vratio)
    if ( nargin < 6 )
        disp(['Not enough parameters specified for quare_node_array function'])
    elseif ( nargin == 6 )
        uratio=1;
        vratio=1;
    elseif ( nargin == 7 )
        vratio=1;
    end

    % get node spacing along u direction
    if ( uratio == 1 )
        xi_pts=linspace(-1,1,numnod_u);
    elseif ( uratio > 0 )
        ru=uratio^(1/(numnod_u-2));
        xi_pts(1)=0;
        d=1;
        for i=2:numnod_u
            xi_pts(i)=xi_pts(i-1)+d;
            d=d/ru;
        end
        xi_pts=2*xi_pts/xi_pts(numnod_u)-1;
    else
        disp('uratio must be greator than 0');
        xi_pts=linspace(-1,1,numnod_u);
    end

    % get node spacing along v direction
    if ( vratio == 1 )
        eta_pts=linspace(-1,1,numnod_v);
    elseif ( vratio > 0 )
        rv=vratio^(1/(numnod_v-2));
        eta_pts(1)=0;
        d=1;
        for i=2:numnod_v
            eta_pts(i)=eta_pts(i-1)+d;
            d=d/rv;
        end
        eta_pts=2*eta_pts/eta_pts(numnod_v)-1;
    else
        disp('vratio must be greator than 0');
        eta_pts=linspace(-1,1,numnod_v);
    end

    x_pts=[pt1(1),pt2(1),pt3(1),pt4(1)];
    y_pts=[pt1(2),pt2(2),pt3(2),pt4(2)];

    for r=1:numnod_v
        eta=eta_pts(r);
        for c=1:numnod_u
            xi=xi_pts(c);
            % get interpolation basis at xi, eta
            N=lagrange_basis('Q4',[xi,eta]);
            N=N(:,1);
            X((r-1)*numnod_u+c,:)=[x_pts*N,y_pts*N];
        end

    end

end % End of Square Node Array

function sctrB = assembly(e,element1)

sctr = element1(e,:);
nn   = length(sctr);

for k = 1 : nn
    sctrBfem(2*k-1) = 2*sctr(k)-1 ;
    sctrBfem(2*k)   = 2*sctr(k)   ;
end
    sctrB = sctrBfem;
end % End of Assembly


function element=make_elem(node_pattern,num_u,num_v,inc_u,inc_v)

% function element=make_elem(node_pattern,num_u,num_v,inc_u,inc_v)
% creates a connectivity list

if ( nargin < 5 )
    disp(['Not enough parameters specified for make_elem function'])
end

inc=[zeros(1,size(node_pattern,2))];
e=1;
element=zeros(num_u*num_v,size(node_pattern,2));

for row=1:num_v
    for col=1:num_u
        element(e,:)=node_pattern+inc;
        inc=inc+inc_u;
        e=e+1;
    end
    inc=row*inc_v;
end
end


function [Elements,Nodes]=q4totq8(element,node,numx,numy)
% forms the element and node matrices for eight node rectangular element,
% from the elemet and node matrices of a four node rectangular element
% with the element and node matrices arranged in a counterclockwish order
% Inputs:-element,node,numx and numy.
nnx=numx+1;
num_u=numx;
num_v=numy;
inc_u=[2 2 2 1 2 2 2 1];
if numx==2
inc_v=[8 8 8 8 8 8 8 8];
else
inc_v=[8+3*(numx-2) 8+3*(numx-2) 8+3*(numx-2) 8+3*(numx-2)...
8+3*(numx-2) 8+3*(numx-2) 8+3*(numx-2) 8+3*(numx-2)];
end
node_pattern=[1 2 3 2*nnx+1 3*nnx+2 3*nnx+1 3*nnx 2*nnx];
inc = [zeros(1,size(node_pattern,2))];
e=1;
elements=zeros(num_u*num_v,size(node_pattern,2));
for row=1:num_v
for col=1:num_u
elements(e,:)=node_pattern+inc;
inc=inc+inc_u;
e=e+1;
end
inc=row*inc_v;
end
Elements=elements;
numNode=size(unique(Elements),1);
Nodes=zeros(numNode,2);
numElement=numx*numy;
for i=1:numElement
Nodes(Elements(i,1),1)=node(element(i,1),1);
Nodes(Elements(i,1),2)=node(element(i,1),2);
Nodes(Elements(i,2),1)=(node(element(i,1),1)+node(element(i,2),1))/2;
Nodes(Elements(i,2),2)= node(element(i,1),2);
Nodes(Elements(i,3),1)=node(element(i,2),1);
Nodes(Elements(i,3),2)=node(element(i,2),2);
Nodes(Elements(i,4),1)=node(element(i,2),1);
Nodes(Elements(i,4),2)=(node(element(i,2),2)+node(element(i,3),2))/2;
Nodes(Elements(i,5),1)=node(element(i,3),1);
Nodes(Elements(i,5),2)=node(element(i,3),2);
Nodes(Elements(i,6),1)=(node(element(i,3),1)+node(element(i,4),1))/2;
Nodes(Elements(i,6),2)= node(element(i,3),2);
Nodes(Elements(i,7),1)=node(element(i,4),1);
Nodes(Elements(i,7),2)=node(element(i,4),2);
Nodes(Elements(i,8),1)=node(element(i,4),1);
Nodes(Elements(i,8),2)=(node(element(i,4),2)+node(element(i,1),2))/2;
end
Nodes=Nodes;
Elements(:,1)=elements(:,1);
Elements(:,2)=elements(:,3);
Elements(:,3)=elements(:,5);
Elements(:,4)=elements(:,7);
Elements(:,5)=elements(:,2);
Elements(:,6)=elements(:,4);
Elements(:,7)=elements(:,6);
Elements(:,8)=elements(:,8);
end % end of function

function [W,Q] = quadrature( quadorder, qt, sdim )

    if ( nargin < 3 )   % set default arguments
        if ( strcmp(qt,'GAUSS') == 1 )
            dim = 1;
        else
            dim = 2;
        end
    end

if ( nargin < 2 )
    type = 'GAUSS';
end

if ( strcmp(qt,'GAUSS') == 1 )

    if ( quadorder > 8 )  % check for valid quadrature order
        disp('Order of quadrature too high for Gaussian Quadrature');
        quadorder =8;
    end

    quadpoint=zeros(quadorder^sdim ,sdim);
    quadweight=zeros(quadorder^sdim,1);

    r1pt=zeros(quadorder,1); r1wt=zeros(quadorder,1);

    switch ( quadorder )
        case 1
            r1pt(1) = 0.000000000000000;
            r1wt(1) = 2.000000000000000;

        case 2
            r1pt(1) = 0.577350269189626;
            r1pt(2) =-0.577350269189626;

            r1wt(1) = 1.000000000000000;
            r1wt(2) = 1.000000000000000;

        case 3
            r1pt(1) = 0.774596669241483;
            r1pt(2) =-0.774596669241483;
            r1pt(3) = 0.000000000000000;

            r1wt(1) = 0.555555555555556;
            r1wt(2) = 0.555555555555556;
            r1wt(3) = 0.888888888888889;

        case 4
            r1pt(1) = 0.861134311594053;
            r1pt(2) =-0.861134311594053;
            r1pt(3) = 0.339981043584856;
            r1pt(4) =-0.339981043584856;

            r1wt(1) = 0.347854845137454;
            r1wt(2) = 0.347854845137454;
            r1wt(3) = 0.652145154862546;
            r1wt(4) = 0.652145154862546;

        case 5
            r1pt(1) = 0.906179845938664;
            r1pt(2) =-0.906179845938664;
            r1pt(3) = 0.538469310105683;
            r1pt(4) =-0.538469310105683;
            r1pt(5) = 0.000000000000000;

            r1wt(1) = 0.236926885056189;
            r1wt(2) = 0.236926885056189;
            r1wt(3) = 0.478628670499366;
            r1wt(4) = 0.478628670499366;
            r1wt(5) = 0.568888888888889;

        case 6
            r1pt(1) = 0.932469514203152;
            r1pt(2) =-0.932469514203152;
            r1pt(3) = 0.661209386466265;
            r1pt(4) =-0.661209386466265;
            r1pt(5) = 0.238619186003152;
            r1pt(6) =-0.238619186003152;

            r1wt(1) = 0.171324492379170;
            r1wt(2) = 0.171324492379170;
            r1wt(3) = 0.360761573048139;
            r1wt(4) = 0.360761573048139;
            r1wt(5) = 0.467913934572691;
            r1wt(6) = 0.467913934572691;

        case 7
            r1pt(1) =  0.949107912342759;
            r1pt(2) = -0.949107912342759;
            r1pt(3) =  0.741531185599394;
            r1pt(4) = -0.741531185599394;
            r1pt(5) =  0.405845151377397;
            r1pt(6) = -0.405845151377397;
            r1pt(7) =  0.000000000000000;

            r1wt(1) = 0.129484966168870;
            r1wt(2) = 0.129484966168870;
            r1wt(3) = 0.279705391489277;
            r1wt(4) = 0.279705391489277;
            r1wt(5) = 0.381830050505119;
            r1wt(6) = 0.381830050505119;
            r1wt(7) = 0.417959183673469;

        case 8
            r1pt(1) =  0.960289856497536;
            r1pt(2) = -0.960289856497536;
            r1pt(3) =  0.796666477413627;
            r1pt(4) = -0.796666477413627;
            r1pt(5) =  0.525532409916329;
            r1pt(6) = -0.525532409916329;
            r1pt(7) =  0.183434642495650;
            r1pt(8) = -0.183434642495650;

            r1wt(1) = 0.101228536290376;
            r1wt(2) = 0.101228536290376;
            r1wt(3) = 0.222381034453374;
            r1wt(4) = 0.222381034453374;
            r1wt(5) = 0.313706645877887;
            r1wt(6) = 0.313706645877887;
            r1wt(7) = 0.362683783378362;
            r1wt(8) = 0.362683783378362;

        otherwise
            disp('Order of quadrature to high for Gaussian Quadrature');

    end  % end of quadorder switch

    n=1;

    if ( sdim == 1 )
        for i = 1:quadorder
            quadpoint(n,:) = [ r1pt(i) ];
            quadweight(n) = r1wt(i);
            n = n+1;
        end

    elseif ( sdim == 2 )
        for i = 1:quadorder
            for j = 1:quadorder
                quadpoint(n,:) = [ r1pt(i), r1pt(j)];
                quadweight(n) = r1wt(i)*r1wt(j);
                n = n+1;
            end
        end

    else % sdim == 3
        for i = 1:quadorder
            for j = 1:quadorder
                for k = 1:quadorder
                    quadpoint(n,:) = [ r1pt(i), r1pt(j), r1pt(k) ];
                    quadweight(n) = r1wt(i)*r1wt(j)*r1wt(k);
                    n = n+1;
                end
            end
        end

    end

    Q=quadpoint;
    W=quadweight;
    % END OF GAUSSIAN QUADRATURE DEFINITION

elseif ( strcmp(qt,'TRIANGULAR') == 1 )

    if ( sdim == 3 )  %%% TETRAHEDRA

        if ( quadorder ~= 1 &  quadorder ~= 2 &  quadorder ~= 3  )
            % check for valid quadrature order
            disp('Incorect quadrature order for triangular quadrature');
            quadorder = 1;
        end

        if  ( quadorder == 1 )
            quadpoint = [ 0.25 0.25 0.25 ];
            quadweight = 1;

        elseif ( quadorder == 2 )
            quadpoint = [ 0.58541020  0.13819660  0.13819660;
                0.13819660  0.58541020  0.13819660;
                0.13819660  0.13819660  0.58541020;
                0.13819660  0.13819660  0.13819660];
            quadweight = [1; 1; 1; 1]/4;

        elseif ( quadorder == 3 )
            quadpoint = [ 0.25  0.25  0.25;
                1/2   1/6   1/6;
                1/6   1/2   1/6;
                1/6   1/6   1/2;
                1/6   1/6   1/6];
            quadweight = [-4/5 9/20 9/20 9/20 9/20]';

        end

        Q=quadpoint;
        W=quadweight/6;

    else  %%% TRIANGLES

        if ( quadorder > 7 ) % check for valid quadrature order
            disp('Quadrature order too high for triangular quadrature');
            quadorder = 1;
        end

        if ( quadorder == 1 )   % set quad points and quadweights
            quadpoint = [ 0.3333333333333, 0.3333333333333 ];
            quadweight = 1;

        elseif ( quadorder == 2 )
            quadpoint = zeros( 3, 2 );
            quadweight = zeros( 3, 1 );

            quadpoint(1,:) = [ 0.1666666666667, 0.1666666666667 ];
            quadpoint(2,:) = [ 0.6666666666667, 0.1666666666667 ];
            quadpoint(3,:) = [ 0.1666666666667, 0.6666666666667 ];

            quadweight(1) = 0.3333333333333;
            quadweight(2) = 0.3333333333333;
            quadweight(3) = 0.3333333333333;

        elseif ( quadorder <= 5 )
            quadpoint = zeros( 7, 2 );
            quadweight = zeros( 7, 1 );

            quadpoint(1,:) = [ 0.1012865073235, 0.1012865073235 ];
            quadpoint(2,:) = [ 0.7974269853531, 0.1012865073235 ];
            quadpoint(3,:) = [ 0.1012865073235, 0.7974269853531 ];
            quadpoint(4,:) = [ 0.4701420641051, 0.0597158717898 ];
            quadpoint(5,:) = [ 0.4701420641051, 0.4701420641051 ];
            quadpoint(6,:) = [ 0.0597158717898, 0.4701420641051 ];
            quadpoint(7,:) = [ 0.3333333333333, 0.3333333333333 ];

            quadweight(1) = 0.1259391805448;
            quadweight(2) = 0.1259391805448;
            quadweight(3) = 0.1259391805448;
            quadweight(4) = 0.1323941527885;
            quadweight(5) = 0.1323941527885;
            quadweight(6) = 0.1323941527885;
            quadweight(7) = 0.2250000000000;

        else
            quadpoint = zeros( 13, 2 );
            quadweight = zeros( 13, 1 );

            quadpoint(1 ,:) = [ 0.0651301029022, 0.0651301029022 ];
            quadpoint(2 ,:) = [ 0.8697397941956, 0.0651301029022 ];
            quadpoint(3 ,:) = [ 0.0651301029022, 0.8697397941956 ];
            quadpoint(4 ,:) = [ 0.3128654960049, 0.0486903154253 ];
            quadpoint(5 ,:) = [ 0.6384441885698, 0.3128654960049 ];
            quadpoint(6 ,:) = [ 0.0486903154253, 0.6384441885698 ];
            quadpoint(7 ,:) = [ 0.6384441885698, 0.0486903154253 ];
            quadpoint(8 ,:) = [ 0.3128654960049, 0.6384441885698 ];
            quadpoint(9 ,:) = [ 0.0486903154253, 0.3128654960049 ];
            quadpoint(10,:) = [ 0.2603459660790, 0.2603459660790 ];
            quadpoint(11,:) = [ 0.4793080678419, 0.2603459660790 ];
            quadpoint(12,:) = [ 0.2603459660790, 0.4793080678419 ];
            quadpoint(13,:) = [ 0.3333333333333, 0.3333333333333 ];

            quadweight(1 ) = 0.0533472356088;
            quadweight(2 ) = 0.0533472356088;
            quadweight(3 ) = 0.0533472356088;
            quadweight(4 ) = 0.0771137608903;
            quadweight(5 ) = 0.0771137608903;
            quadweight(6 ) = 0.0771137608903;
            quadweight(7 ) = 0.0771137608903;
            quadweight(8 ) = 0.0771137608903;
            quadweight(9 ) = 0.0771137608903;
            quadweight(10) = 0.1756152576332;
            quadweight(11) = 0.1756152576332;
            quadweight(12) = 0.1756152576332;
            quadweight(13) =-0.1495700444677;

        end

        Q=quadpoint;
        W=quadweight/2;   % ATTENTION ATTENTION WHY DIVIDE TO 2?????
    end

end  % end of TRIANGULAR initialization
end
% END OF FUNCTION

function [B,J0] = xfemBmatrix1(pt,elemType,e,node1,element1)

sctr = element1(e,:);
nn   = length(sctr);
[N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions
J0 = node1(sctr,:)'*dNdxi;                 % element Jacobian matrix
invJ0 = inv(J0);
dNdx  = dNdxi*invJ0;                      % derivatives of N w.r.t XY
Gpt = N' * node1(sctr,:);                  % GP in global coord, used

% Bfem is always computed
Bfem = zeros(3,2*nn);
Bfem(1,1:2:2*nn)  = dNdx(:,1)' ;
Bfem(2,2:2:2*nn)  = dNdx(:,2)' ;
Bfem(3,1:2:2*nn)  = (dNdx(:,2))' ;
Bfem(3,2:2:2*nn)  = (dNdx(:,1))' ;
B = Bfem;
end              % end of switch 


function [N2,B] = xfemBmatrix2(pt,elemType,e,node2,element2)

sctr = element2(e,:);
nn   = length(sctr);
[N,dNdxi] = lagrange_basis(elemType,pt);  % element shape functions
J0 = node2(sctr,:)'*dNdxi;                 % element Jacobian matrix
invJ0 = inv(J0);
dNdx  = dNdxi*invJ0;                      % derivatives of N w.r.t XY

N2 = zeros(3,3*nn);
N2(1,1:3:3*nn) = N(:,1)';
N2(2,2:3:3*nn) = N(:,1)';
N2(3,3:3:3*nn) = N(:,1)';

% Bfem is always computed
Bfem = zeros(6,3*nn);
Bfem(1,1:3:3*nn)  = dNdx(:,1)' ;
Bfem(2,1:3:3*nn)  = dNdx(:,2)' ;
Bfem(3,2:3:3*nn)  = dNdx(:,1)' ;
Bfem(4,2:3:3*nn)  = dNdx(:,2)' ;
Bfem(5,3:3:3*nn)  = dNdx(:,1)' ;
Bfem(6,3:3:3*nn)  = dNdx(:,2)' ;
B = Bfem;
end              % end of switch 


function conn = tricheck(node,conn,verbose)

% FUNCTION
%
%   conn=tricheck(node,conn,verbose)
%
% This function check wether a triangle has a negative Jacobian, and if
% so reorders it so that the the Jacobian is positive.

if ( nargin==2 )
    verbose=0;
end

if ( size(node,2)==3 )
    node=node(:,1:2);
end

count=0;

for e=1:size(conn,1)

    sctr=conn(e,:);
    [N,dNdxi]=lagrange_basis('T3',[1/3 1/3]);
    detJ=det(node(sctr,:)'*dNdxi);

    if ( detJ < 0 )
        %disp(['NEGATIVE JACOBIAN IN ELEMENT ',num2str(e)])
        conn(e,:)=fliplr(sctr);
        count=count+1;
    elseif ( detJ == 0 )
        disp(['ZERO JACOBIAN IN ELEMENT ',num2str(e),' CANNOT FIX'])
    end
end

if ( verbose )
    disp(['TRICHECK FOUND ',num2str(count),' NEGATIVE JACOBIANS, ALL FIXED'])
end
end % END OF FUNCTION tricheck


function [node,element] = meshRegion(pt1, pt2, pt3, pt4, numx, numy, elemType)

switch elemType

    case 'Q4'           % here we generate the mesh of Q4 elements
        nnx=numx+1;
        nny=numy+1;
        node=square_node_array(pt1,pt2,pt3,pt4,nnx,nny);
        inc_u=1;
        inc_v=nnx;
        node_pattern=[ 1 2 nnx+2 nnx+1 ];
        [element]=make_elem(node_pattern,numx,numy,inc_u,inc_v);

    case 'Q8'           % here we generate a mesh of Q9 elements
        nnx=numx+1;
        nny=numy+1;
        node=square_node_array(pt1,pt2,pt3,pt4,nnx,nny);
        inc_u=1;
        inc_v=nnx;
        node_pattern=[ 1 2 nnx+2 nnx+1 ];
        element=make_elem(node_pattern,numx,numy,inc_u,inc_v);
        [element,node]=q4totq8(element,node,numx,numy);

    otherwise
        error('For now, only Q4 and Q9 are supported by the mesh generator');
end

end % END OF FUNCTION meshRegion


function [Omega] = compute_damage(kappa_gpt,kappa0_gpt,alpha,beta)
    if kappa_gpt < kappa0_gpt
        Omega = 0;
    else   
        a = (kappa0_gpt/kappa_gpt);
        c = beta*(kappa_gpt - kappa0_gpt);
        temp = (1-alpha) + alpha*exp(-c);
        Omega = 1 - a*temp;
    end
end % END OF FUNCTION compute_damage


function [g,dgdomega] = interaction_function(eta,omega,R)

    num = (1-R)*exp(-eta*omega) + R - exp(-eta);
    den = 1 - exp(-eta);
    g = num/den;
    num1 = (R-1)*eta*exp(-eta*omega);
    dgdomega = num1/den;

end % END OF FUNCTION interaction_function


function [Nv,dNdxi] = lagrange_basis(type,coord,dim)

    if ( nargin == 2 )
        dim=1;
    end

    switch type
        case 'Q4'
            %%%%%%%%%%%%%%% Q4 FOUR NODE QUADRILATERIAL ELEMENT %%%%%%%%%%%%%%%%
            %
            %    4--------------------3
            %    |                    |
            %    |                    |
            %    |                    |
            %    |                    |
            %    |                    |
            %    |                    |
            %    |                    |
            %    |                    |
            %    |                    |
            %    1--------------------2
            %
            if size(coord,2) < 2
                disp('Error two coordinates needed for the Q4 element')
            else
                xi=coord(1); eta=coord(2);
                N=1/4*[ (1-xi)*(1-eta);
                    (1+xi)*(1-eta);
                    (1+xi)*(1+eta);
                    (1-xi)*(1+eta)];
                dNdxi=1/4*[-(1-eta), -(1-xi);
                    1-eta,    -(1+xi);
                    1+eta,      1+xi;
                    -(1+eta),   1-xi];
            end
          case 'Q8'
            %%%%%%%%%%%%%%% Q8 FOUR NODE QUADRILATERIAL ELEMENT %%%%%%%%%%%%%%%%
            %
            %    4---------7----------3
            %    |                    |
            %    |                    |
            %    |                    |
            %    |                    |
            %    8                    6
            %    |                    |
            %    |                    |
            %    |                    |
            %    |                    |
            %    1---------5----------2
            %
            if size(coord,2) < 2
            disp('Error two coordinates needed for the Q8 element')
            else
            xi=coord(1); eta=coord(2);
            N=1/4*[-1*(1-xi)*(1-eta)*(1+xi+eta);
                    -1*(1+xi)*(1-eta)*(1-xi+eta);
                    -1*(1+xi)*(1+eta)*(1-xi-eta);
                    -1*(1-xi)*(1+eta)*(1+xi-eta);
                    2*(1-xi^2)*(1-eta);
                    2*(1+xi)*(1-eta^2);
                    2*(1-xi^2)*(1+eta);
                    2*(1-xi)*(1-eta^2)];
            dNdxi=1/4*[(1-eta)*(2*xi+eta),  (1-xi)*(2*eta+xi);
                        (1-eta)*(2*xi-eta), (1+xi)*(2*eta-xi);
                        (1+eta)*(2*xi+eta), (1+xi)*(2*eta+xi);
                        (1+eta)*(2*xi-eta), (1-xi)*(2*eta-xi);
                        -4*xi*(1-eta),      -2*(1-xi^2);
                        2*(1-eta^2),        -4*eta*(1+xi);
                        -4*xi*(1+eta),       2*(1-xi^2);
                        -2*(1-eta^2),       -4*eta*(1-xi)];
            end

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        otherwise
            disp(['Element ',type,' not yet supported'])
            N=[]; dNdxi=[];
    end

    I=eye(dim);
    Nv=[];
    
        for i=1:size(N,1)
            Nv=[Nv;I*N(i)];
        end

    if ( dim == 1 )
        B=dNdxi;
    elseif ( dim == 2 )
        B=zeros(dim*size(N,1),3);

        B(1:dim:dim*size(N,1)-1,1) = dNdxi(:,1);
        B(2:dim:dim*size(N,1),2)   = dNdxi(:,2);

        B(1:dim:dim*size(N,1)-1,3) = dNdxi(:,2);
        B(2:dim:dim*size(N,1),3)   = dNdxi(:,1);
    elseif ( dim == 3 )
        B=zeros(dim*size(N,1),6);

        disp('Error: need to add 3D N and dNdxi')

        B(1:dim:dim*size(N,1)-2,1) = dNdxi(:,1);
        B(2:dim:dim*size(N,1)-1,2) = dNdxi(:,2);
        B(3:dim:dim*size(N,1),3)   = dNdxi(:,3);

        B(2:dim:dim*size(N,1)-1,4) = dNdxi(:,3);
        B(3:dim:dim*size(N,1),4)   = dNdxi(:,2);

        B(3:dim:dim*size(N,1),5)   = dNdxi(:,1);
        B(1:dim:dim*size(N,1)-2,5) = dNdxi(:,3);

        B(1:dim:dim*size(N,1)-2,6) = dNdxi(:,2);
        B(2:dim:dim*size(N,1)-1,6) = dNdxi(:,1);

    end

end % % END OF FUNCTION lagrange_basis

function plot_mesh(X,connect,elem_type,se)

% function plot_mesh(X,connect,elem_type,linespec) plots a nodal mesh and 
% an associated connectivity.  X contains nodal coordinates, connect is the connectivity,
% and elem_type is either 'L2', 'L3', 'T3', 'T6', 'Q4', or 'Q9'
% depending on the element topology.

    if ( nargin < 4 )
        se='w-';
    end

    holdState=ishold;
    hold on

    % fill X if needed
    if (size(X,2) < 3)
        for c=size(X,2)+1:3
            X(:,c)=[zeros(size(X,1),1)];
        end
    end

    for e=1:size(connect,1)

        if ( strcmp(elem_type,'Q9') )       % 9-node quad element
            ord=[1,5,2,6,3,7,4,8,1];
        elseif ( strcmp(elem_type,'Q8') )  % 8-node quad element
            ord=[1,5,2,6,3,7,4,8,1];
        elseif ( strcmp(elem_type,'T3') )  % 3-node triangle element
            ord=[1,2,3,1];
        elseif ( strcmp(elem_type,'T6') )  % 6-node triangle element
            ord=[1,4,2,5,3,6,1];
        elseif ( strcmp(elem_type,'Q4') )  % 4-node quadrilateral element
            ord=[1,2,3,4,1];
        elseif ( strcmp(elem_type,'L2') )  % 2-node line element
            ord=[1,2];
        elseif ( strcmp(elem_type,'L3') )  % 3-node line element
            ord=[1,3,2];
        elseif ( strcmp(elem_type,'H4') )  % 4-node tet element
            ord=[1,2,4,1,3,4,2,3];
        elseif ( strcmp(elem_type,'B8') )  % 8-node brick element
            ord=[1,5,6,2,3,7,8,4,1,2,3,4,8,5,6,7];
        end

        for n=1:size(ord,2)
            xpt(n)=X(connect(e,ord(n)),1);
            ypt(n)=X(connect(e,ord(n)),2);
            zpt(n)=X(connect(e,ord(n)),3);
        end
        plot3(xpt,ypt,zpt,se)
    end

    rotate3d on
    axis equal

    if ( ~holdState )
        hold off
    end
end % END OF FUNCTION plotmesh

function U = element_disp(e,u,node1,element1)

% From the unknowns vector u, extract the parameters
% associated with the element "e"
% Then epsilon = B*U

    sctr = element1(e,:);
    nn   = length(sctr);

    % stdU contains true nodal displacement
    idx = 0 ;
    stdU   = zeros(2*nn,1);
    for in = 1 : nn
        idx = idx + 1;
        nodeI = sctr(in) ;
        stdU(2*idx-1) = u(2*nodeI-1);
        stdU(2*idx)   = u(2*nodeI  );
    end

    U = stdU;

end % END OF FUNCTION element_disp

function [mises_gp] = Compute_Von_Mises_Stress(stress_gpt)
    sigxx = stress_gpt(1,1);
    sigyy = stress_gpt(2,1);
    sigxy = stress_gpt(3,1);
    a = (sigxx + sigyy)/2;
    b = (sigxx - sigyy)/2;
    sig1 = a + sqrt((b^2) + (sigxy^2));
    sig2 = a - sqrt((b^2) + (sigxy^2));
    mises_gp = sqrt(0.5*((sig1-sig2)^2 + sig2^2 + sig1^2)) ;
end

function [sig1, sig2, alpha] = Compute_Principal_Stress(stress_gpt)
    sigxx = stress_gpt(1,1);
    sigyy = stress_gpt(2,1);
    sigxy = stress_gpt(3,1);
    a = (sigxx + sigyy)/2;
    b = (sigxx - sigyy)/2;
    sig1 = a + sqrt((b^2) + (sigxy^2));
    sig2 = a - sqrt((b^2) + (sigxy^2));
    den = (sigxx - sigyy);
    if den==0
        alpha = 90;
    else
        p = (2*sigxy)/den;
        alpha = 0.5*atand(p);
    end
end

function [alpha] = Compute_Principal_Angle(stress_gpt)
    sigxx = stress_gpt(1,1);
    sigyy = stress_gpt(2,1);
    sigxy = stress_gpt(3,1);
    if sigxy==0
        alpha = 0;
    else
        p = (2*sigxy)/(sigxx - sigyy);
        alpha = 0.5*atand(p);
    end
end

function [Gpnt] = computing_gauss_location(numelem,elemType,node2,element2)
gpnt = 0;
Gpnt = zeros(4*numelem,2);
Gpnt_Wt_detJ = zeros(4*numelem,1);
for iel = 1:numelem % Loop on elements
    order = 2;
    [W,Q] = quadrature(order,'GAUSS',2);  
    sctr2 = element2(iel,:); % Element connectivity 
    
  for kk = 1 : size(W,1) 
        gpnt = gpnt + 1;
        pt = Q(kk,:);   % Quadrature point 
        [N,dNdxi] = lagrange_basis(elemType,pt);
        J0 = node2(sctr2,:)'*dNdxi;                 % element Jacobian matrix       
        gpt_loc = N' * node2(sctr2,:);
        Gpnt(gpnt,:) = gpt_loc;  % GP in global coord, used
        Gpnt_Wt_detJ(gpnt,1) = W(kk);
        Gpnt_Wt_detJ(gpnt,2) = det(J0);
  end
end
end

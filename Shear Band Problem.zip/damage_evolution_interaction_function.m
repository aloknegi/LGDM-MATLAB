% % Evolution of the damage parameter ? 
function damage_evolution_interaction_function
clear
close all; 
clc;
L = 60; % Length of the plate
% gpt_no = 20;
gpt_no = 348;
load('SB_80by80_Beta_250_Date_07_07_19_Eta_4_R04_340steps_Vandoren','INTERACTION_DATA','forcevdisp');
totat_steps = size(forcevdisp,2);
int_g_1 = INTERACTION_DATA(gpt_no,:);
disp_1 = (forcevdisp(1,2:1:totat_steps)/L)*1e3;
plot(disp_1,int_g_1,'-');
hold on
load('SB_80by80_Beta_120_Date_11_02_19_Eta_4_R04_340steps','INTERACTION_DATA','forcevdisp');
int_g_2 = INTERACTION_DATA(gpt_no,:);
disp_2 = (forcevdisp(1,2:1:totat_steps)/L)*1e3;
plot(disp_2,int_g_2,'--')
legend({'s','g'},'Location','northeast','FontSize',8);
x0 = 100;
y0 = 100;
width=250;
height=175;
set(gcf,'units','points','position',[x0,y0,width,height])
axis([0 1.4
    0 1]);
end
clc;
close all;
kappa0_gpt = 0.00005;
eta = 2;
alpha = 0.99;
count = 1;
g =[];
omega = [];
dgdomega1  = [];
for i = 0.00005:0.001:0.0210
    kappa_gpt = i;
    gd = (kappa0_gpt/kappa_gpt)^eta;
    dgdomega1 = -(eta*kappa0_gpt*(kappa0_gpt/kappa_gpt)^(eta - 1))/kappa_gpt^2;
    g(count,1) = gd;
    dgdomega(count,1) = dgdomega1;
    omega(count,1) = i;
    count = count + 1;
end

plot(omega,g,'-')